# PathForge STL test pack — how to use it

13 test parts. Each one tests a different thing CAM software can get wrong.
All sizes are in **millimetres**, and every part sits on Z = 0.

## How to test (for each file)

1. In PathForge, click **Import STL** and choose the file.
2. Check the message at the top-left of the 3D view (triangles and parts).
3. Keep the default settings: tool **3.175 mm**, **Full Job (best)**, Tormach 770.
4. Click **⚙ Generate G-Code** and wait for the preview window.
5. Compare with the table below. **PASSED** plus numbers close to these = correct.
6. Optional: save the `.nc` and open it in **ncviewer.com** or **CAMotics** to see it with another program.

## Expected results (measured with PathForge v4.3, default settings)

"Within 0.05 mm" = how much of the surface ends up within 0.05 mm of the model.
"Most left" = the biggest spot of material the tool cannot reach — normal in
places a 3.175 mm tool physically can't get into (explained per part).

| File | What it tests | Parts detected | Expected | Within 0.05 mm | Most left | What "most left" is |
|---|---|---|---|---|---|---|
| 01_block_40x30x10 | Simplest case — check the size | 1 | PASSED | 100 % | 0 mm | — |
| 02_stepped_block | Flat step floor at exact height (6 mm) | 2 | PASSED | 100 % | 0 mm | — |
| 03_plate_with_pocket | Closed pocket 20 × 16 × 6 deep: ramp entry, inside corners | 1 | PASSED | 99.9 % | 6 mm | The 4 sharp inside corners of the pocket (a round tool leaves a 1.6 mm radius) |
| 04_ring_with_hole | Through hole Ø16 inside a Ø40 ring | 1 | PASSED | 100 % | 10 mm | A few tiny specks on the polygon facets of the hole |
| 05_dome_R20 | Curved surface, half sphere | 1 | PASSED | ~90 % | ~1 mm | Small ridges ("scallops") of a flat end mill on a curve |
| 06_pyramid_40x40x25 | Sloped flat faces | 1 | PASSED | ~71 % | ~0.4 mm | Stair-step ridges on the slopes (normal for a flat end mill) |
| 07_mushroom_overhang | Cap wider than its stem | 1 | PASSED | 100 % | 20 mm | Under the cap — no 3-axis machine can reach it. The tool must NOT cut the cap |
| 08_thin_rib_and_slot | 1 mm rib and a 2 mm slot (smaller than the tool) | 4 | PASSED | 99 % | 10 mm | Inside the 2 mm slot — a 3.175 mm tool can't fit |
| 09_wavy_surface | Free-form curved surface | 1 | PASSED | ~93 % | ~0.3 mm | Scallops |
| 10_two_part_assembly | Two separate parts in one file | 2 | PASSED | 100 % | 8 mm | Specks on the round part's facets |
| 11_big_detailed_100k | Speed with ~100,000 triangles | 1 | PASSED (takes 2–4 min) | ~72 % | ~1.1 mm | Fine details smaller than the tool |
| 12_text_format_cube_25 | Text (ASCII) STL format | 1 | PASSED | 100 % | 0 mm | — |
| 13_broken_empty_file | A broken file | — | **"Import Error"** message, no crash | — | — | — |

## Extra checks worth doing

- **01 block in inches**: set Units to *Inches (G20)* → still PASSED, and the file
  says `(UNITS INCH)` and `G20` near the top.
- **01 block with zero in the centre**: X0 Y0 = *Centre of stock* → coordinates in the
  file become negative and positive around 0.
- **06 pyramid with Finish stepover 0.1**: within 0.05 mm goes from ~71 % to ~82 %, and the
  most material left drops from ~0.4 mm to ~0.06 mm. Cut time goes from ~56 to ~84 min.
- **03 pocket with a 6 mm tool** (Tool diameter 6): the pocket still cuts, with
  bigger corners left.
- **08 rib with a 10 mm tool**: still PASSED. The tool is too big to get between the
  features, and the software correctly stays out instead of forcing it.
- Try each strategy (Rough Clear, Waterline Z, Parallel X, Parallel Y) on 02 and 05.

## What would be a REAL problem (send me the file + settings)

- The app crashes or freezes for more than 10 minutes.
- **PROBLEMS FOUND** on any of files 01–12.
- "Deepest cut into the part" bigger than 0.005 mm.
- The G-code viewer shows a move that flies off far outside the stock.
- File 13 crashes the app instead of showing a message.

## Reference G-code

`01_block_40x30x10_REFERENCE_Tormach.nc` and `06_pyramid_40x40x25_REFERENCE_Tormach.nc`
were made with default settings. With the same settings your file should
match them (only the first title line can differ).
